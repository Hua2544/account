package com.hua.config;



import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.mapper.MapperScannerConfigurer;
import org.springframework.context.annotation.Bean;

import javax.sql.DataSource;

public class MybatisConfig {
 @Bean
  public SqlSessionFactoryBean sqlSessionFactory(DataSource dataSource){
     SqlSessionFactoryBean bean=new SqlSessionFactoryBean();
     bean.setDataSource(dataSource);
     bean.setTypeAliasesPackage("com.hua.domain");
     return bean;
  }
  @Bean
  public MapperScannerConfigurer  mapperScannerConfigurer(){
   MapperScannerConfigurer mapperScannerConfigurer =new MapperScannerConfigurer();
   mapperScannerConfigurer.setBasePackage("com.hua.dao");
   return mapperScannerConfigurer;
  }


}
