package com.hua.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@Configuration
@ComponentScan({"com.hua.controller","com.hua.config","com.hua.dao","com.hua.domain"})
@EnableWebMvc
public class SpringmvcConfig {
}
