package com.hua.domain;

public class Account {
    private Integer id;
    private String name;
    private Float balance;
    private Float balanceIn;
    private Float balanceOut;
    private Integer actionId;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "Account{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", balance=" + balance +
                ", balanceIn=" + balanceIn +
                ", balanceOut=" + balanceOut +
                ", actionId=" + actionId +
                '}';
    }

    public void setName(String name) {
        this.name = name;
    }

    public Float getBalance() {
        return balance;
    }

    public void setBalance(Float balance) {
        this.balance = balance;
    }

    public Float getBalanceIn() {
        return balanceIn;
    }

    public void setBalanceIn(Float balanceIn) {
        this.balanceIn = balanceIn;
    }

    public Float getBalanceOut() {
        return balanceOut;
    }

    public void setBalanceOut(Float balanceOut) {
        this.balanceOut = balanceOut;
    }

    public Integer getActionId() {
        return actionId;
    }

    public void setActionId(Integer actionId) {
        this.actionId = actionId;
    }
}
