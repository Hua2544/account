package com.hua.dao;

import com.hua.domain.Account;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

public interface AccountDao {
    @Insert("insert into account (ID,Name,Balance,BalanceIn,BalanceOut,ActionId)values(null,#{name},#{balance},#{balanceIn},#{balanceOut},#{actionId})")
    public void save(Account account);
    @Update("update account set Name=#{name},Balance=#{balance},BalanceIn=#{balanceIn},BalanceOut=#{balanceOut},ActionId=#{actionId}) where ID=#{id}")
    public void update(Account account);
    @Select("select * from  account where id=#{id}")
    public Account getById(Integer id);
    @Select("select * from account")
    public List<Account> getAll();

}
