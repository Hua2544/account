package com.hua.controller;


import com.hua.domain.Account;
import com.hua.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/account")
public class AccountController {
    @Autowired
    private AccountService accountServiceImpl;
    //查询所有 可以用来查询收入支出明细 查询用户钱包余额
    @GetMapping
    public Result getAll() {
        List<Account> accounts=accountServiceImpl.getAll();
        Integer code=accounts!=null ? Code.GET_OK : Code.GET_ERR;
        String msg=accounts !=null ? "":"数据查询失败，请重试";
        return new Result(code,accounts,msg);
    }
    @GetMapping("/{id}")
    public Result getById(@PathVariable Integer id) {
        Account account= accountServiceImpl.getById(id);
        Integer code=account!=null ? Code.GET_OK : Code.GET_ERR;
        String msg=account !=null ? "":"数据查询失败，请重试";
        return new Result(code,account,msg);
    }
    @PostMapping
    public Result save(@RequestBody Account account) {
        boolean flag= accountServiceImpl.save(account);
        return  new Result(flag ? Code.SAVE_OK: Code.SAVE_ERR,flag);
    }

    @PutMapping
    public Result update(@RequestBody Account account) {
        boolean flag= accountServiceImpl.update(account);
        return  new Result(flag ? Code.UPDATE_OK: Code.UPDATE_ERR,flag);
    }


//    @DeleteMapping("/{id}")
//    public Result delete(@PathVariable Integer id) {
//
//        boolean flag= accountServiceImpl.delete(id);
//        return  new Result(flag ? Code.DELETE_OK: Code.DELETE_ERR,flag);
//
//    }


    //收入支出接口
    @PostMapping
    public Result balanceInOut(@RequestBody Account account) {
        Account account1= new Account();
        account1.setBalanceIn(account.getBalanceIn());
        account1.setBalanceOut(account.getBalanceOut());
        account1.setBalance(account.getBalance()+account.getBalanceIn()-account.getBalanceOut());
        account1.setActionId(account.getActionId()+1);
        boolean flag= accountServiceImpl.update(account);
        Integer code=account1!=null ? Code.GET_OK : Code.GET_ERR;
        String msg=account1 !=null && flag ? "":"数据操作失败，请重试";
        return new Result(code,account1,msg);
    }



}
