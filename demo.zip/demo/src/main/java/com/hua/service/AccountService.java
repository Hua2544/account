package com.hua.service;


import com.hua.domain.Account;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Transactional
public interface AccountService {

    public boolean save(Account account);
    public boolean update(Account account);
//    public boolean delete(Integer id);
    public Account getById(Integer id);
    public List<Account> getAll();
}
