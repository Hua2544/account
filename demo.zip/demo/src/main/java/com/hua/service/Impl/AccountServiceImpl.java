package com.hua.service.Impl;

import com.hua.dao.AccountDao;
import com.hua.domain.Account;
import com.hua.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AccountServiceImpl implements AccountService {
   @Autowired
    private AccountDao accountDao; //error改wanring
    /**
     *
     * @param account
     * @return
     */
    @Override
    public boolean save(Account account) {
        accountDao.save(account);
        return true;
    }

    @Override
    public boolean update(Account account) {
        accountDao.update(account);
        return true;
    }

//    @Override
//    public boolean delete(Integer id) {
//        accountDao.delete(id);
//        return true;
//    }

    @Override
    public Account getById(Integer id) {
        return accountDao.getById(id);
    }

    @Override
    public List<Account> getAll() {
        return accountDao.getAll();
    }
}